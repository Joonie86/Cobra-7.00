#ifndef __DRM_H__
#define __DRM_H__

void drm_init(void);

int sys_drm_get_data(void *data, uint64_t param);

#endif /* __DRM_H__ */
 
